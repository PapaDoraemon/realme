package a;

import com.topjohnwu.magisk.NoUIActivity;

public class g extends NoUIActivity {
    /* stub */
}
