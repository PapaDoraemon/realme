package a;

import com.topjohnwu.magisk.FlashActivity;

public class f extends FlashActivity {
    /* stub */
}
