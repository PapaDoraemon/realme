package a;

import com.topjohnwu.magisk.MainActivity;

public class b extends MainActivity {
    /* stub */
}
