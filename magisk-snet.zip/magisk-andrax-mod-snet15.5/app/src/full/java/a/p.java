package a;

import com.topjohnwu.magisk.SuRequestActivity;

public class p extends SuRequestActivity {
    /* stub */
}
