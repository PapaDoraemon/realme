package a;

import com.topjohnwu.magisk.utils.BootSigner;

import androidx.annotation.Keep;

@Keep
public class a extends BootSigner {
    /* stub */
}
