package a;

import com.topjohnwu.magisk.services.UpdateCheckService;

public class n extends UpdateCheckService {
    /* stub */
}
