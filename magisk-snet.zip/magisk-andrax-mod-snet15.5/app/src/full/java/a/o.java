package a;

import android.content.Context;
import android.util.AttributeSet;

import com.topjohnwu.magisk.components.AboutCardRow;

public class o extends AboutCardRow {
    /* stub */

    public o(Context context) {
        super(context);
    }

    public o(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public o(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }
}
