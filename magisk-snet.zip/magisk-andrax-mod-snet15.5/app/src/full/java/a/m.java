package a;

import com.topjohnwu.magisk.services.OnBootService;

public class m extends OnBootService {
    /* stub */
}
