package a;

import com.topjohnwu.magisk.receivers.RebootReceiver;

public class k extends RebootReceiver {
    /* stub */
}
