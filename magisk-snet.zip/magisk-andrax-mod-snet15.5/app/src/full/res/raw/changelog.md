### 6.0.1
- Update to use new online module's organizing method
- When fingerprint authentication is enabled, toggling root permissions in "Superuser" section now requires fingerprint beforehand
- Fix crashes when entering MagiskHide section on some devices
- Remove support to Magisk version lower than v15.0
- Ask storage permissions before patching stock boot image
- Update dark theme CardView color
