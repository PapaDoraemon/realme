# Moded Magisk Manager to perfect run ANDRAX

## FIX Screen ISSUES AND NEW BUGS IN SUPERUSER

### How to INSTALL?

Simple, to install **YOU NEED REMOVE COMPLETELY SUPERSU OR OFICIAL MAGISK**. So download [MAGISK-ANDRAX-MOD.ZIP](https://github.com/The-Cracker-Technology/magisk-andrax-mod/releases/)

### Modules

MAGISK-ANDRAX-MOD has compatibility with the modules of the official magisk
